# DH-SK Hub

A personal command center — notes, files, and an offline AI chat assistant,
backed by a live dashboard. Built with plain HTML, CSS, and JavaScript.
No build step, no backend, no dependencies.

## How to run it

You have two options:

**Option 1 — just open it (simplest)**
Double-click `index.html`, or right-click → Open with → your browser.
That's it. Everything runs client-side.

**Option 2 — run a local server (recommended)**
Some browsers restrict certain features (like `FileReader` in the file
manager) more strictly when opened directly from disk (`file://`). A local
server avoids any of that friction:

```bash
# Python 3
cd dh-sk-hub
python3 -m http.server 8000
# then open http://localhost:8000 in your browser

# or, if you have Node.js
npx serve .
```

## How it works

- **Accounts**: Registering creates a user record in `localStorage`
  (`dhsk_users`). This is a demo-grade auth system — passwords are stored
  in plain text in the browser, which is fine for a local personal tool but
  should never be copied into anything handling real user data.
- **Per-user data**: Notes, files, and chat history are each saved under a
  key scoped to your email (e.g. `dhsk_notes_you@example.com`), so multiple
  accounts on the same browser don't mix data.
- **Files**: Uploaded files are read as base64 and stored directly in
  `localStorage`. Most browsers cap `localStorage` at roughly 5MB per site,
  so the file manager enforces a 2MB-per-file soft limit to keep things
  healthy. For a production tool you'd swap this for `IndexedDB` or a real
  backend.
- **AI Chat**: The assistant is fully offline and rule-based — it handles
  greetings, arithmetic, and questions about your own notes/files. It does
  not call any external API, so it works with no internet connection and
  no API key.
- **Theme**: Dark mode is the default; your choice is remembered across
  visits via `localStorage`.

## File structure

```
dh-sk-hub/
├── index.html   — all page markup (home, login, register, dashboard, notes, files, chat)
├── style.css    — all styling, theming, and responsive rules
├── script.js    — all behavior: auth, routing, CRUD, storage, chat logic
└── README.md    — this file
```

## Customizing

- **Colors**: Edit the CSS variables at the top of `style.css` under
  `:root` (dark theme) and `html[data-theme="light"]` (light theme).
- **Chatbot replies**: Edit `generateBotReply()` in `script.js` to add new
  rules or response patterns.
- **Storage limits**: Adjust `MAX_SIZE` inside `handleFiles()` in
  `script.js` if you want to allow larger files (at the risk of hitting
  the browser's storage ceiling sooner).
