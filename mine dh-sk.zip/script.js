/* =========================================================================
   DH-SK HUB — APPLICATION SCRIPT
   Everything is plain JavaScript, no frameworks, no build step.
   Data lives entirely in the browser's localStorage:
     dhsk_users         -> array of registered users (demo-grade auth)
     dhsk_session       -> currently logged-in user's email
     dhsk_notes_<email> -> array of notes, scoped per user
     dhsk_files_<email> -> array of files, scoped per user
     dhsk_chat_<email>  -> array of chat messages, scoped per user
   Structure of this file:
     1. Storage helpers
     2. State & DOM cache
     3. Toast notifications
     4. Theme (dark / light mode)
     5. Routing between "pages"
     6. Authentication (register / login / logout)
     7. Dashboard (stats + recent items)
     8. Notes manager
     9. File manager
    10. AI chatbot (simple rule-based simulation, fully offline)
    11. Mobile navigation drawer
    12. Init
   ========================================================================= */

(() => {
  "use strict";

  /* =======================================================================
     1. STORAGE HELPERS
     Small wrapper functions so the rest of the code never touches
     localStorage directly — easier to read, easier to swap out later.
  ======================================================================= */
  const Store = {
    get(key, fallback) {
      try {
        const raw = localStorage.getItem(key);
        return raw ? JSON.parse(raw) : fallback;
      } catch (err) {
        console.warn(`Could not read "${key}" from storage:`, err);
        return fallback;
      }
    },
    set(key, value) {
      try {
        localStorage.setItem(key, JSON.stringify(value));
        return true;
      } catch (err) {
        console.warn(`Could not write "${key}" to storage:`, err);
        showToast("Storage is full or unavailable. Try removing old files.", "error");
        return false;
      }
    },
    remove(key) {
      localStorage.removeItem(key);
    },
  };

  // Per-user keys so multiple accounts on the same browser don't mix data.
  const userKey = (suffix) => `dhsk_${suffix}_${state.currentUser?.email ?? "anon"}`;

  /* =======================================================================
     2. STATE & DOM CACHE
  ======================================================================= */
  const state = {
    currentUser: null, // { name, email }
    notes: [],
    files: [],
    chat: [],
    notesFilter: { search: "", color: "all" },
    filesFilter: { search: "" },
  };

  const $ = (sel, root = document) => root.querySelector(sel);
  const $all = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  const el = {
    topbar: $("#topbar"),
    mainNav: $("#mainNav"),
    userAvatar: $("#userAvatar"),
    userName: $("#userName"),
    themeToggle: $("#themeToggle"),
    themeToggleLanding: $("#themeToggleLanding"),
    logoutBtn: $("#logoutBtn"),
    logoutBtnMobile: $("#logoutBtnMobile"),
    hamburger: $("#hamburger"),
    mobileDrawer: $("#mobileDrawer"),
    drawerBackdrop: $("#drawerBackdrop"),
    toastHost: $("#toastHost"),
  };

  /* =======================================================================
     3. TOAST NOTIFICATIONS
     Small, unobtrusive confirmations for create/update/delete actions.
  ======================================================================= */
  function showToast(message, type = "info", duration = 2600) {
    const toast = document.createElement("div");
    toast.className = `toast toast--${type}`;
    toast.textContent = message;
    el.toastHost.appendChild(toast);

    setTimeout(() => {
      toast.classList.add("is-leaving");
      toast.addEventListener("animationend", () => toast.remove(), { once: true });
    }, duration);
  }

  /* =======================================================================
     4. THEME (DARK / LIGHT MODE)
     Preference is saved so it persists across visits.
  ======================================================================= */
  function applyTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    Store.set("dhsk_theme", theme);
  }

  function toggleTheme() {
    const current = document.documentElement.getAttribute("data-theme") || "dark";
    applyTheme(current === "dark" ? "light" : "dark");
  }

  function initTheme() {
    // Default to dark (the brand's natural mode); respect saved preference.
    const saved = Store.get("dhsk_theme", "dark");
    applyTheme(saved);
    el.themeToggle.addEventListener("click", toggleTheme);
    el.themeToggleLanding.addEventListener("click", toggleTheme);
  }

  /* =======================================================================
     5. ROUTING
     "Pages" are <section class="page" data-page="...">. We only ever
     show one at a time by toggling .is-active. Links/buttons declare
     where they go via [data-route] or [data-action].
  ======================================================================= */
  function showPage(pageName) {
    $all(".page").forEach((page) => {
      page.classList.toggle("is-active", page.dataset.page === pageName);
    });

    // Keep the top nav's active state in sync with the visible page.
    $all(".navlink[data-route]").forEach((btn) => {
      btn.classList.toggle("is-active", btn.dataset.route === pageName);
    });

    closeMobileDrawer();
    window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });

    // Page-specific refresh hooks
    if (pageName === "dashboard") renderDashboard();
    if (pageName === "notes") renderNotes();
    if (pageName === "files") renderFiles();
    if (pageName === "chatbot") {
      renderChatHistory();
      scrollChatToBottom();
    }
  }

  function goToApp(defaultPage = "dashboard") {
    el.topbar.hidden = false;
    showPage(defaultPage);
  }

  function goToLanding() {
    el.topbar.hidden = true;
    showPage("home");
  }

  // Central click handler: anything with data-route or data-action
  // is wired here instead of attaching dozens of individual listeners.
  document.addEventListener("click", (e) => {
    const routeBtn = e.target.closest("[data-route]");
    if (routeBtn) {
      showPage(routeBtn.dataset.route);
      return;
    }

    const actionBtn = e.target.closest("[data-action]");
    if (actionBtn) {
      const action = actionBtn.dataset.action;
      if (action === "show-home") goToLanding();
      if (action === "show-login") showPage("login");
      if (action === "show-register") showPage("register");
    }
  });

  /* =======================================================================
     6. AUTHENTICATION
     Demo-grade only: passwords are stored in localStorage, NOT hashed.
     This is intentional for a front-end-only, no-backend project — never
     reuse this pattern for an app handling real user data.
  ======================================================================= */
  function getUsers() {
    return Store.get("dhsk_users", []);
  }

  function saveUsers(users) {
    Store.set("dhsk_users", users);
  }

  function findUser(email) {
    return getUsers().find((u) => u.email.toLowerCase() === email.toLowerCase());
  }

  function initials(name) {
    return name
      .trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((w) => w[0]?.toUpperCase() ?? "")
      .join("") || "?";
  }

  function setSession(email) {
    Store.set("dhsk_session", email);
  }

  function clearSession() {
    Store.remove("dhsk_session");
  }

  function loadCurrentUser() {
    const email = Store.get("dhsk_session", null);
    if (!email) return null;
    const user = findUser(email);
    return user ? { name: user.name, email: user.email } : null;
  }

  function applyUserChrome() {
    if (!state.currentUser) return;
    el.userAvatar.textContent = initials(state.currentUser.name);
    el.userName.textContent = state.currentUser.name;
    $("#dashGreetName").textContent = state.currentUser.name.split(" ")[0];
  }

  function loadUserData() {
    state.notes = Store.get(userKey("notes"), []);
    state.files = Store.get(userKey("files"), []);
    state.chat = Store.get(userKey("chat"), []);
  }

  function handleRegister(e) {
    e.preventDefault();
    const name = $("#registerName").value.trim();
    const email = $("#registerEmail").value.trim();
    const password = $("#registerPassword").value;
    const errorEl = $("#registerError");
    errorEl.hidden = true;

    if (!name || !email || password.length < 6) {
      errorEl.textContent = "Please fill every field — password needs at least 6 characters.";
      errorEl.hidden = false;
      return;
    }
    if (findUser(email)) {
      errorEl.textContent = "An account with this email already exists. Try logging in instead.";
      errorEl.hidden = false;
      return;
    }

    const users = getUsers();
    users.push({ name, email, password }); // demo-only plain storage, see note above
    saveUsers(users);
    setSession(email);

    state.currentUser = { name, email };
    loadUserData();
    applyUserChrome();
    $("#registerForm").reset();
    showToast(`Welcome to DH-SK Hub, ${name.split(" ")[0]}!`, "success");
    goToApp("dashboard");
  }

  function handleLogin(e) {
    e.preventDefault();
    const email = $("#loginEmail").value.trim();
    const password = $("#loginPassword").value;
    const errorEl = $("#loginError");
    errorEl.hidden = true;

    const user = findUser(email);
    if (!user || user.password !== password) {
      errorEl.textContent = "Email or password is incorrect.";
      errorEl.hidden = false;
      return;
    }

    setSession(user.email);
    state.currentUser = { name: user.name, email: user.email };
    loadUserData();
    applyUserChrome();
    $("#loginForm").reset();
    showToast(`Welcome back, ${user.name.split(" ")[0]}!`, "success");
    goToApp("dashboard");
  }

  function handleLogout() {
    clearSession();
    state.currentUser = null;
    state.notes = [];
    state.files = [];
    state.chat = [];
    goToLanding();
    showToast("Logged out. Your data is saved for next time.", "info");
  }

  function initAuth() {
    $("#registerForm").addEventListener("submit", handleRegister);
    $("#loginForm").addEventListener("submit", handleLogin);
    el.logoutBtn.addEventListener("click", handleLogout);
    el.logoutBtnMobile.addEventListener("click", handleLogout);
  }

  /* =======================================================================
     7. DASHBOARD
     Live stat cards with a count-up animation, plus "recent" lists fed
     straight from the notes/files arrays — no separate data source.
  ======================================================================= */
  function animateCount(elNode, target) {
    const start = 0;
    const duration = 600;
    const startTime = performance.now();

    function tick(now) {
      const progress = Math.min((now - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
      elNode.textContent = Math.round(start + (target - start) * eased);
      if (progress < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }

  function formatBytes(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }

  function timeAgo(timestamp) {
    const diff = Date.now() - timestamp;
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return "just now";
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    const days = Math.floor(hrs / 24);
    return `${days}d ago`;
  }

  function renderDashboard() {
    if (!state.currentUser) return;

    $("#dashDate").textContent = new Date().toLocaleDateString(undefined, {
      weekday: "long", year: "numeric", month: "long", day: "numeric",
    });

    animateCount($("#statNotes"), state.notes.length);
    animateCount($("#statPinned"), state.notes.filter((n) => n.pinned).length);
    animateCount($("#statFiles"), state.files.length);
    animateCount($("#statMessages"), state.chat.length);

    // Recent notes (top 4, pinned first, then newest)
    const recentNotes = [...state.notes]
      .sort((a, b) => (b.pinned - a.pinned) || (b.updatedAt - a.updatedAt))
      .slice(0, 4);

    const notesListEl = $("#dashRecentNotes");
    notesListEl.innerHTML = recentNotes.length
      ? recentNotes.map((n) => `
          <li>
            <span class="dot" style="background:${colorToHex(n.color)}"></span>
            <span class="title">${escapeHtml(n.title)}</span>
            <span class="meta">${timeAgo(n.updatedAt)}</span>
          </li>
        `).join("")
      : `<li class="empty-row">No notes yet — create your first one.</li>`;

    // Recent files (top 4, newest first)
    const recentFiles = [...state.files].sort((a, b) => b.addedAt - a.addedAt).slice(0, 4);
    const filesListEl = $("#dashRecentFiles");
    filesListEl.innerHTML = recentFiles.length
      ? recentFiles.map((f) => `
          <li>
            <span class="dot" style="background:var(--accent-2)"></span>
            <span class="title">${escapeHtml(f.name)}</span>
            <span class="meta">${formatBytes(f.size)}</span>
          </li>
        `).join("")
      : `<li class="empty-row">No files yet.</li>`;

    // Rough storage usage indicator (localStorage has no hard universal
    // limit, but ~5MB per origin is a common browser default).
    const usedBytes = new Blob([
      JSON.stringify(state.notes) + JSON.stringify(state.files) + JSON.stringify(state.chat),
    ]).size;
    const estimatedLimit = 5 * 1024 * 1024; // 5MB, a conservative common cap
    const pct = Math.min(100, (usedBytes / estimatedLimit) * 100);
    $("#storageFill").style.width = `${pct}%`;
    $("#storageLabel").textContent = `${formatBytes(usedBytes)} used in this browser (of ~5 MB typical limit)`;
  }

  function colorToHex(color) {
    const map = { violet: "#7C5CFF", amber: "#FFB454", teal: "#37D2B0", rose: "#FF6FA0" };
    return map[color] || map.violet;
  }

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  /* =======================================================================
     8. NOTES MANAGER
     CRUD over state.notes, persisted to localStorage after every change.
     Supports search, color filtering, pinning, and a modal editor.
  ======================================================================= */
  function saveNotes() {
    Store.set(userKey("notes"), state.notes);
  }

  function openNoteModal(note = null) {
    const backdrop = $("#noteModalBackdrop");
    $("#noteModalTitle").textContent = note ? "Edit note" : "New note";
    $("#noteId").value = note?.id ?? "";
    $("#noteTitle").value = note?.title ?? "";
    $("#noteContent").value = note?.content ?? "";
    $("#notePinned").checked = !!note?.pinned;

    const targetColor = note?.color ?? "violet";
    $all(".color-dot", $("#noteColorPicker")).forEach((dot) => {
      dot.classList.toggle("is-active", dot.dataset.color === targetColor);
    });

    backdrop.hidden = false;
    setTimeout(() => $("#noteTitle").focus(), 50);
  }

  function closeNoteModal() {
    $("#noteModalBackdrop").hidden = true;
    $("#noteForm").reset();
  }

  function handleNoteSubmit(e) {
    e.preventDefault();
    const id = $("#noteId").value;
    const title = $("#noteTitle").value.trim();
    const content = $("#noteContent").value.trim();
    const pinned = $("#notePinned").checked;
    const color = $(".color-dot.is-active", $("#noteColorPicker"))?.dataset.color || "violet";

    if (!title || !content) {
      showToast("A note needs both a title and some content.", "error");
      return;
    }

    if (id) {
      // Editing an existing note
      const note = state.notes.find((n) => n.id === id);
      if (note) {
        Object.assign(note, { title, content, pinned, color, updatedAt: Date.now() });
        showToast("Note updated.", "success");
      }
    } else {
      // Creating a new note
      state.notes.unshift({
        id: crypto.randomUUID ? crypto.randomUUID() : `note_${Date.now()}_${Math.random()}`,
        title, content, pinned, color,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });
      showToast("Note created.", "success");
    }

    saveNotes();
    closeNoteModal();
    renderNotes();
  }

  function deleteNote(id) {
    state.notes = state.notes.filter((n) => n.id !== id);
    saveNotes();
    renderNotes();
    showToast("Note deleted.", "info");
  }

  function togglePin(id) {
    const note = state.notes.find((n) => n.id === id);
    if (note) {
      note.pinned = !note.pinned;
      note.updatedAt = Date.now();
      saveNotes();
      renderNotes();
    }
  }

  function renderNotes() {
    const { search, color } = state.notesFilter;
    const filtered = state.notes
      .filter((n) => color === "all" || n.color === color)
      .filter((n) =>
        !search ||
        n.title.toLowerCase().includes(search) ||
        n.content.toLowerCase().includes(search)
      )
      .sort((a, b) => (b.pinned - a.pinned) || (b.updatedAt - a.updatedAt));

    const grid = $("#notesGrid");
    const emptyState = $("#notesEmptyState");

    if (!filtered.length) {
      grid.innerHTML = "";
      emptyState.hidden = false;
      return;
    }
    emptyState.hidden = true;

    grid.innerHTML = filtered.map((n, i) => `
      <article class="note-card" style="--note-color:${colorToHex(n.color)}; --delay:${i}; animation-delay:${i * 35}ms;">
        <div class="note-card__head">
          <h3 class="note-card__title">${escapeHtml(n.title)}</h3>
          <button class="note-card__pin" data-pin="${n.id}" title="${n.pinned ? "Unpin" : "Pin"}">${n.pinned ? "📌" : "📍"}</button>
        </div>
        <p class="note-card__body">${escapeHtml(n.content)}</p>
        <div class="note-card__foot">
          <span class="note-card__date">${timeAgo(n.updatedAt)}</span>
          <div class="note-card__actions">
            <button data-edit="${n.id}" title="Edit">✏️</button>
            <button data-delete="${n.id}" class="danger" title="Delete">🗑️</button>
          </div>
        </div>
      </article>
    `).join("");
  }

  function initNotes() {
    $("#newNoteBtn").addEventListener("click", () => openNoteModal());
    $("#closeNoteModal").addEventListener("click", closeNoteModal);
    $("#cancelNoteBtn").addEventListener("click", closeNoteModal);
    $("#noteForm").addEventListener("submit", handleNoteSubmit);

    $("#noteModalBackdrop").addEventListener("click", (e) => {
      if (e.target.id === "noteModalBackdrop") closeNoteModal();
    });

    $("#noteColorPicker").addEventListener("click", (e) => {
      const dot = e.target.closest(".color-dot");
      if (!dot) return;
      $all(".color-dot", $("#noteColorPicker")).forEach((d) => d.classList.remove("is-active"));
      dot.classList.add("is-active");
    });

    $("#notesSearch").addEventListener("input", (e) => {
      state.notesFilter.search = e.target.value.trim().toLowerCase();
      renderNotes();
    });

    $("#colorFilter").addEventListener("click", (e) => {
      const chip = e.target.closest(".chip");
      if (!chip) return;
      $all(".chip", $("#colorFilter")).forEach((c) => c.classList.remove("is-active"));
      chip.classList.add("is-active");
      state.notesFilter.color = chip.dataset.color;
      renderNotes();
    });

    // Delegated clicks for dynamically-rendered note cards
    $("#notesGrid").addEventListener("click", (e) => {
      const editId = e.target.closest("[data-edit]")?.dataset.edit;
      const deleteId = e.target.closest("[data-delete]")?.dataset.delete;
      const pinId = e.target.closest("[data-pin]")?.dataset.pin;

      if (editId) openNoteModal(state.notes.find((n) => n.id === editId));
      if (deleteId) {
        if (confirm("Delete this note? This can't be undone.")) deleteNote(deleteId);
      }
      if (pinId) togglePin(pinId);
    });

    // Keyboard shortcut: Escape closes the modal
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && !$("#noteModalBackdrop").hidden) closeNoteModal();
    });
  }

  /* =======================================================================
     9. FILE MANAGER
     Files are read via FileReader and stored as base64 data URLs in
     localStorage. This works well for small files; localStorage has a
     ~5MB-per-origin ceiling in most browsers, so very large files will
     fail gracefully with a toast (see Store.set's error handling).
  ======================================================================= */
  function saveFiles() {
    Store.set(userKey("files"), state.files);
  }

  function fileIcon(type) {
    if (type.startsWith("image/")) return "🖼️";
    if (type.includes("pdf")) return "📕";
    if (type.includes("zip") || type.includes("rar")) return "🗜️";
    if (type.startsWith("video/")) return "🎞️";
    if (type.startsWith("audio/")) return "🎵";
    if (type.includes("text") || type.includes("json") || type.includes("javascript")) return "📄";
    return "📦";
  }

  function handleFiles(fileList) {
    const files = Array.from(fileList);
    const MAX_SIZE = 2 * 1024 * 1024; // 2MB soft cap per file, keeps localStorage healthy

    let accepted = 0;
    let rejected = 0;

    files.forEach((file) => {
      if (file.size > MAX_SIZE) {
        rejected++;
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        state.files.unshift({
          id: crypto.randomUUID ? crypto.randomUUID() : `file_${Date.now()}_${Math.random()}`,
          name: file.name,
          type: file.type || "application/octet-stream",
          size: file.size,
          data: reader.result, // base64 data URL
          addedAt: Date.now(),
        });
        saveFiles();
        renderFiles();
      };
      reader.readAsDataURL(file);
      accepted++;
    });

    if (accepted) showToast(`${accepted} file${accepted > 1 ? "s" : ""} added.`, "success");
    if (rejected) showToast(`${rejected} file${rejected > 1 ? "s" : ""} skipped — over the 2MB limit.`, "error");
  }

  function deleteFile(id) {
    state.files = state.files.filter((f) => f.id !== id);
    saveFiles();
    renderFiles();
    showToast("File deleted.", "info");
  }

  function downloadFile(id) {
    const file = state.files.find((f) => f.id === id);
    if (!file) return;
    const a = document.createElement("a");
    a.href = file.data;
    a.download = file.name;
    a.click();
  }

  function renderFiles() {
    const search = state.filesFilter.search;
    const filtered = state.files
      .filter((f) => !search || f.name.toLowerCase().includes(search))
      .sort((a, b) => b.addedAt - a.addedAt);

    $("#filesCount").textContent = `${state.files.length} file${state.files.length === 1 ? "" : "s"}`;

    const grid = $("#filesGrid");
    const emptyState = $("#filesEmptyState");

    if (!filtered.length) {
      grid.innerHTML = "";
      emptyState.hidden = false;
      return;
    }
    emptyState.hidden = true;

    grid.innerHTML = filtered.map((f, i) => `
      <article class="file-card" style="animation-delay:${i * 35}ms;">
        <div class="file-card__preview">
          ${f.type.startsWith("image/")
            ? `<img src="${f.data}" alt="${escapeHtml(f.name)}" />`
            : `<span>${fileIcon(f.type)}</span>`}
        </div>
        <span class="file-card__name" title="${escapeHtml(f.name)}">${escapeHtml(f.name)}</span>
        <span class="file-card__meta">${formatBytes(f.size)} · ${timeAgo(f.addedAt)}</span>
        <div class="file-card__actions">
          <button data-download="${f.id}">Download</button>
          <button data-delete-file="${f.id}" class="danger">Delete</button>
        </div>
      </article>
    `).join("");
  }

  function initFiles() {
    const dropzone = $("#dropzone");
    const fileInput = $("#fileInput");

    // No click listener needed here — the <label for="fileInput"> markup
    // already opens the file picker natively when clicked.

    fileInput.addEventListener("change", (e) => {
      if (e.target.files.length) handleFiles(e.target.files);
      fileInput.value = ""; // allow re-selecting the same file later
    });

    ["dragenter", "dragover"].forEach((evt) =>
      dropzone.addEventListener(evt, (e) => {
        e.preventDefault();
        dropzone.classList.add("is-dragover");
      })
    );
    ["dragleave", "drop"].forEach((evt) =>
      dropzone.addEventListener(evt, (e) => {
        e.preventDefault();
        dropzone.classList.remove("is-dragover");
      })
    );
    dropzone.addEventListener("drop", (e) => {
      if (e.dataTransfer.files.length) handleFiles(e.dataTransfer.files);
    });

    $("#filesSearch").addEventListener("input", (e) => {
      state.filesFilter.search = e.target.value.trim().toLowerCase();
      renderFiles();
    });

    $("#filesGrid").addEventListener("click", (e) => {
      const downloadId = e.target.closest("[data-download]")?.dataset.download;
      const deleteId = e.target.closest("[data-delete-file]")?.dataset.deleteFile;
      if (downloadId) downloadFile(downloadId);
      if (deleteId) {
        if (confirm("Delete this file? This can't be undone.")) deleteFile(deleteId);
      }
    });
  }

  /* =======================================================================
     10. AI CHATBOT
     A fully offline, rule-based assistant — no API calls, no network.
     It can: hold small talk, do arithmetic, report on the user's own
     notes/files counts, and give a friendly fallback otherwise. This
     keeps the "AI chat" feature genuinely functional without requiring
     an API key or server, in line with the project's local-only design.
  ======================================================================= */
  function saveChat() {
    Store.set(userKey("chat"), state.chat);
  }

  function scrollChatToBottom() {
    const box = $("#chatMessages");
    box.scrollTop = box.scrollHeight;
  }

  function appendChatMessage(role, text) {
    const box = $("#chatMessages");
    const msg = document.createElement("div");
    msg.className = `chat-msg chat-msg--${role}`;
    msg.innerHTML = `
      <span class="chat-msg__avatar">${role === "user" ? "🙂" : "🤖"}</span>
      <div class="chat-msg__bubble">${escapeHtml(text)}</div>
    `;
    box.appendChild(msg);
    scrollChatToBottom();
  }

  function renderChatHistory() {
    const box = $("#chatMessages");
    // Keep the friendly intro bubble, then replay saved history after it.
    box.innerHTML = `
      <div class="chat-msg chat-msg--bot">
        <span class="chat-msg__avatar">🤖</span>
        <div class="chat-msg__bubble">
          Hi! I'm your offline assistant. I can't browse the web, but I can chat,
          do quick math, and help you think through notes and files. Try asking
          me something.
        </div>
      </div>
    `;
    state.chat.forEach((m) => appendChatMessage(m.role, m.text));
  }

  // Try to evaluate a simple arithmetic expression safely (no eval()).
  function tryMath(input) {
    const cleaned = input.replace(/[^0-9+\-*/().\s]/g, "");
    if (!cleaned.trim() || !/[0-9]/.test(cleaned)) return null;
    // Only proceed if the original message looks like a math question.
    if (!/^[\d\s+\-*/().]+$/.test(cleaned) || cleaned.trim().length < 1) return null;
    try {
      // Function constructor instead of eval — restricted to arithmetic chars above.
      const result = Function(`"use strict"; return (${cleaned})`)();
      if (typeof result === "number" && Number.isFinite(result)) return result;
    } catch {
      return null;
    }
    return null;
  }

  function generateBotReply(userText) {
    const text = userText.trim();
    const lower = text.toLowerCase();

    // Greetings
    if (/^(hi|hello|hey|salut|hola|سلام|اهلا)\b/.test(lower)) {
      return "Hey there! What can I help you with — notes, files, or just talk?";
    }

    // Math
    const mathResult = tryMath(text);
    if (mathResult !== null) {
      return `That comes out to ${mathResult}.`;
    }

    // Asking about notes
    if (lower.includes("note")) {
      const count = state.notes.length;
      const pinned = state.notes.filter((n) => n.pinned).length;
      if (count === 0) return "You don't have any notes yet — head to the Notes page to write your first one.";
      return `You currently have ${count} note${count === 1 ? "" : "s"}, ${pinned} of them pinned.`;
    }

    // Asking about files
    if (lower.includes("file")) {
      const count = state.files.length;
      if (count === 0) return "No files stored yet — drop something in on the Files page.";
      return `You have ${count} file${count === 1 ? "" : "s"} saved in this browser.`;
    }

    // Time / date
    if (lower.includes("time") || lower.includes("date") || lower.includes("today")) {
      return `Right now it's ${new Date().toLocaleString()}.`;
    }

    // Thanks
    if (lower.includes("thank")) {
      return "Anytime! That's what I'm here for.";
    }

    // How are you
    if (lower.includes("how are you")) {
      return "Running smoothly, thanks for asking! How's your day going?";
    }

    // Who are you / about
    if (lower.includes("who are you") || lower.includes("what are you")) {
      return "I'm the built-in assistant for DH-SK Hub — a small, offline helper that lives entirely in this page.";
    }

    // Fallback — still useful, never a dead end
    const fallbacks = [
      "I'm a simple offline assistant, so I might not catch everything — but I can do math, and tell you about your notes and files.",
      "Not sure I followed that one. Try asking me to do some math, or ask about your notes or files.",
      "I'll be honest, that's outside what I can do offline. Want me to check your note or file count instead?",
    ];
    return fallbacks[Math.floor(Math.random() * fallbacks.length)];
  }

  function handleChatSubmit(e) {
    e.preventDefault();
    const input = $("#chatInput");
    const text = input.value.trim();
    if (!text) return;

    appendChatMessage("user", text);
    state.chat.push({ role: "user", text, at: Date.now() });
    input.value = "";

    // Show a brief "typing" indicator before the reply, for a more natural feel.
    const box = $("#chatMessages");
    const typingEl = document.createElement("div");
    typingEl.className = "chat-msg chat-msg--bot chat-msg--typing";
    typingEl.innerHTML = `
      <span class="chat-msg__avatar">🤖</span>
      <div class="chat-msg__bubble">
        <span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span>
      </div>
    `;
    box.appendChild(typingEl);
    scrollChatToBottom();

    setTimeout(() => {
      typingEl.remove();
      const reply = generateBotReply(text);
      appendChatMessage("bot", reply);
      state.chat.push({ role: "bot", text: reply, at: Date.now() });
      saveChat();
    }, 450 + Math.random() * 400);
  }

  function initChat() {
    $("#chatForm").addEventListener("submit", handleChatSubmit);
    $("#clearChatBtn").addEventListener("click", () => {
      if (!confirm("Clear the whole conversation? This can't be undone.")) return;
      state.chat = [];
      saveChat();
      renderChatHistory();
      showToast("Conversation cleared.", "info");
    });
  }

  /* =======================================================================
     11. MOBILE NAVIGATION DRAWER
  ======================================================================= */
  function openMobileDrawer() {
    el.mobileDrawer.classList.add("is-open");
    el.drawerBackdrop.classList.add("is-open");
  }
  function closeMobileDrawer() {
    el.mobileDrawer.classList.remove("is-open");
    el.drawerBackdrop.classList.remove("is-open");
  }
  function initMobileNav() {
    el.hamburger.addEventListener("click", openMobileDrawer);
    el.drawerBackdrop.addEventListener("click", closeMobileDrawer);
  }

  /* =======================================================================
     12. INIT
     Restores a logged-in session (if any) and wires up every feature.
  ======================================================================= */
  function init() {
    initTheme();
    initAuth();
    initNotes();
    initFiles();
    initChat();
    initMobileNav();

    const restoredUser = loadCurrentUser();
    if (restoredUser) {
      state.currentUser = restoredUser;
      loadUserData();
      applyUserChrome();
      renderChatHistory();
      goToApp("dashboard");
    } else {
      goToLanding();
    }
  }

  document.addEventListener("DOMContentLoaded", init);
})();
